# iTax Advisors: Life Sciences sector page (developer package)

Two NEW sector pages (not on the live site yet): Life Sciences at /sectors/life-sciences-rd-tax-relief/ and Software, SaaS and AI at /sectors/software-saas-ai-rd-tax-relief/. Point the sector tiles and links to it. Header and footer are NOT included; they stay as the site's own shell.

## Folders
- `developer/<page>/index.html`: full page with title, meta description, canonical, Open Graph and schema (JSON-LD) already in the head.
- `developer/assets/img`, `css`, `js`: shared images and one CSS and JS file per page. Paths are relative (`../assets/...`), so upload the `assets` folder and keep the structure, or change the paths to your media library.
- `preview/`: single-file versions with images embedded. Open in any browser to see the finished look. Not for the live site.

## Pages, URLs and SEO
| Page | Live URL (keep the same) | Meta title | Meta description | H1 | Target keyword |
|---|---|---|---|---|---|
| Life Sciences (NEW page) | https://www.itaxadvisors.co.uk/sectors/life-sciences-rd-tax-relief/ | R&D Tax Relief for Life Sciences UK | iTax Advisors | R&D tax relief for life sciences, biotech and MedTech companies: clinical trial costs, CRO contracts, overseas costs and HMRC-ready claims. Speak to a specialist. | R&D Tax Relief for Life Sciences, Biotechnology & MedTech Companies | R&D tax relief life sciences |
| Software, SaaS and AI (NEW page) | https://www.itaxadvisors.co.uk/sectors/software-saas-ai-rd-tax-relief/ | R&D Tax Relief for Software, SaaS & AI | iTax Advisors | R&D tax relief for software, SaaS, AI and fintech companies: what qualifies, developer costs, cloud and contractor spend, and evidence HMRC expects. Speak to a specialist. | R&D Tax Relief for Software Development, SaaS, AI & Fintech Companies | R&D tax relief software |

## Notes for the developer
1. **URLs stay the same.** These replace the content of existing live pages. Do not change slugs.
2. **Schema and Yoast.** Each page has its own JSON-LD (Service/AboutPage/ContactPage, FAQPage, BreadcrumbList). Yoast also outputs a WebPage, Organization and BreadcrumbList. Keep only one BreadcrumbList and one Organization/ProfessionalService per page, and keep the FAQPage.
3. **Meta title and description:** set them in Yoast from the table above (they are also in each head).
4. **Page template:** build on a blank page template (as the home page does). The CSS includes base styles (body, headings, buttons) and expects the site's fixed header (78px) above it.
5. **Enquiry form:** only the Contact page has a form. It posts to the same Make.com webhook the home page uses (`contact`), and only on itaxadvisors.co.uk, so previews never send leads. Every other page sends visitors to /contact-us/. Check the Make scenario receives `lead_source = contact-page-form`.
6. **Links:** every itaxadvisors.co.uk link was checked and returns 200. `/#checklist`, `/#sectors`, `/#life-sciences` are anchors on the live home page. Sector tiles on the Services hub and About link to `/#sectors` until sector pages exist. LinkedIn links are copied from the live home page.
7. **Fonts:** Raleway from Google Fonts (already used on the site).
8. **Images:** all images are in the folder and keep their natural proportions (no stretching or cropping).
9. **Not on these pages:** the PDF checklists. The live PDF URLs for the HMRC and clinical trials checklists currently return 404, so check the uploads before relying on the home page lead magnet.


## SEO and accuracy review: what was changed
- Meta titles and descriptions replaced with the reviewed versions (also set as real `<title>` / `<meta name=description>` in each head).
- Schema: one shared `@id` for the business (`https://www.itaxadvisors.co.uk/#organization`, same as Yoast) and for the founder; the Person is linked to the business.
- About: heading changed from the plural 'Ex-Deloitte R&D tax specialists' to 'Founder-led R&D tax expertise'.
- Services hub: 'You receive' line added to each service, the repeated four-step KRID section replaced by a short 'working with your technical and finance teams' section, utilities mentioned alongside the five sectors.
- Claim Preparation: claim notification period now says 'period of account'; dated update that notification is relevant only until 31 March 2027 (source: client checklist, HMRC guidance checked 5 November 2026); AIF same-day sequence added; all 15 readiness checks shown in full; HMRC guidance links added; KRID software wording says experts oversee and the platform does not replace their judgement.
- Claim Review: FAQ reworded ('Who can independently review an existing R&D tax claim?'); upset-my-adviser question replaced by 'What happens if an independent review identifies weaknesses'; timeline clarified.
- HMRC Enquiry Support: prominent deadline warning; time-limit wording qualified (start date depends on company and on whether the return was on time, late or amended); payment hold no longer described as automatically a formal enquiry; new Schedule 36 section; source and review note.
- Contemporaneous Reporting: retrospective comparison reworded to evidence gaps instead of implying extra HMRC scrutiny.
- Contact: 'A few details are enough to get started'; failed-project FAQ reworded so failure alone does not imply eligibility.

## Still needs input from the client (not added, because it is not in the website or documents)
- Case studies and an example claim review report; an illustrative reporting example and downloadable reporting template.
- Expanded founder biography with verifiable credentials links; KRID development story; data protection and validation details for the KRID software; publication and review dates on technical articles.
- A response-time promise for the enquiry confirmation message, and a named UK R&D tax specialist to review the tax wording before launch.
- Form hardening: the Make.com webhook is called in no-cors mode, so the page cannot read the real result. Add server-side validation, spam protection and an error path.
- The home page (client's live page) still says 'Four details are enough to start' and 'Absolutely' in the failed-projects FAQ; update those there too.

Content on every page comes from the live iTax Advisors website (service pages, About, Senior management, KRID page, blog posts) and the documents the client shared (sector documents and the three checklists).