(function(){
var reduce=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
var fine=window.matchMedia&&window.matchMedia('(pointer:fine)').matches;
var $=function(s,c){return (c||document).querySelector(s)},$$=function(s,c){return Array.prototype.slice.call((c||document).querySelectorAll(s))};
window.$=$;window.$$=$$;
if('IntersectionObserver' in window&&!reduce){
  var vh0=window.innerHeight,items=$$('.rv,.wipe');
  items.forEach(function(el){if(el.getBoundingClientRect().top>vh0*0.95)el.classList.add('pending')});
  document.documentElement.classList.add('anim');
  var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}})},{threshold:0.01,rootMargin:'0px 0px 18% 0px'});
  items.forEach(function(el){if(el.classList.contains('pending'))io.observe(el);else el.classList.add('in')});
  setTimeout(function(){items.forEach(function(el){el.classList.add('in')})},7000);
}
if(!reduce&&fine){
  $$('.mag').forEach(function(b){b.addEventListener('pointermove',function(e){var r=b.getBoundingClientRect();b.style.transform='translate('+((e.clientX-r.left-r.width/2)*.18)+'px,'+((e.clientY-r.top-r.height/2)*.28)+'px)'});b.addEventListener('pointerleave',function(){b.style.transform=''})});
  $$('.tilt').forEach(function(c){c.addEventListener('pointermove',function(e){var r=c.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;c.style.transform='perspective(900px) rotateY('+(x*6)+'deg) rotateX('+(-y*6)+'deg) translateY(-5px)'});c.addEventListener('pointerleave',function(){c.style.transform=''})});
  var hero=$('#hero'),glow=$('#glow');
  if(hero&&glow){hero.addEventListener('pointermove',function(e){var r=hero.getBoundingClientRect();glow.style.opacity=1;glow.style.left=(e.clientX-r.left)+'px';glow.style.top=(e.clientY-r.top)+'px'});hero.addEventListener('pointerleave',function(){glow.style.opacity=0})}
}
window.MAKE_WEBHOOKS={pdf:'https://hook.eu2.make.com/1wn2tf9j4qmrcp4532uak6vpeu4rmgk6',contact:'https://hook.eu2.make.com/1ufcyla1no7bwoprohh6hi4zqame1tg8'};
window.wireForm=function(formId,doneId,errId,fields,type,extraData){
  var f=$('#'+formId),d=$('#'+doneId),err=$('#'+errId);if(!f)return;
  var live=/(^|\.)itaxadvisors\.co\.uk$/.test(location.hostname);
  f.addEventListener('submit',function(e){e.preventDefault();err.textContent='';
    for(var i=0;i<fields.length;i++){var el=$('#'+fields[i]);var bad=el.type==='checkbox'?!el.checked:!el.value.trim();
      if(el.type==='email'&&el.value&&!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(el.value))bad=true;
      if(bad){err.textContent=el.type==='checkbox'?'Please tick the box so we can contact you.':'Please complete: '+(el.labels&&el.labels[0]?el.labels[0].textContent.replace(/\(optional\)/,'').trim():'this field')+'.';el.focus();return}}
    var btn=f.querySelector('button[type="submit"]'),orig=btn.innerHTML;
    function ok(){f.hidden=true;d.classList.add('show')}
    /* Same Make.com webhooks as the live home page. In previews (any other host) no real lead is sent. */
    if(!live){ok();return}
    var data={};new FormData(f).forEach(function(v,k){data[k]=typeof v==='string'?v.trim():v});
    var cb=f.querySelector('input[type="checkbox"]');data.consent=cb&&cb.checked?'yes':'no';
    data.submitted_at=new Date().toISOString();data.page_url=location.href;
    var x=typeof extraData==='function'?extraData():{};Object.keys(x).forEach(function(k){data[k]=x[k]});
    btn.disabled=true;btn.textContent='Sending...';
    fetch(window.MAKE_WEBHOOKS[type||'contact'],{method:'POST',mode:'no-cors',body:new URLSearchParams(data)}).then(ok).catch(function(){err.textContent='We could not send your details. Please try again or contact us by email.';btn.disabled=false;btn.innerHTML=orig});
  });
};
})();

(function(){
var tabs=$$('#clist .lbtn');
function pick(i){tabs.forEach(function(t,k){var on=k===i;t.setAttribute('aria-selected',on?'true':'false');t.tabIndex=on?0:-1;var p=$('#'+t.getAttribute('aria-controls'));if(p)p.hidden=!on})}
tabs.forEach(function(t,i){t.addEventListener('click',function(){pick(i)});t.addEventListener('keydown',function(e){var n=e.key==='ArrowDown'||e.key==='ArrowRight'?1:e.key==='ArrowUp'||e.key==='ArrowLeft'?-1:0;if(n){e.preventDefault();var j=(i+n+tabs.length)%tabs.length;pick(j);tabs[j].focus()}})});
pick(0);
/* count-up figures */
var nums=$$('[data-count]');
function fmt(v,el){var d=parseInt(el.getAttribute('data-dec')||'0',10);var s=d?v.toFixed(d):Math.round(v).toLocaleString('en-GB');return (el.getAttribute('data-prefix')||'')+s+(el.getAttribute('data-suffix')||'')}
function run(el){var to=parseFloat(el.getAttribute('data-count'));var t0=null;function f(t){if(!t0)t0=t;var p=Math.min(1,(t-t0)/1100),e=1-Math.pow(1-p,3);el.textContent=fmt(to*e,el);if(p<1)requestAnimationFrame(f);else el.textContent=fmt(to,el)}requestAnimationFrame(f)}
var reduce=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
if('IntersectionObserver' in window&&!reduce){var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){run(e.target);io.unobserve(e.target)}})},{threshold:.6});nums.forEach(function(n){io.observe(n)})}
wireForm('ct-form','ct-done','ct-err',['ct-first','ct-last','ct-email','ct-co','ct-type','ct-consent'],'contact');
wireForm('lm-form','lm-done','lm-err',['lm-name','lm-email','lm-co','lm-consent'],'pdf',function(){return {checklist_name:'Clinical Trials & R&D Tax Relief: pre-trial checklist',checklist_file:'https://www.itaxadvisors.co.uk/wp-content/uploads/itax-clinical-trials-checklist.pdf',checklist_filename:'itax-clinical-trials-checklist.pdf',lead_source:'life-sciences-page-lead-magnet-clinical-trials'}});
})();

/* jump nav highlight */
(function(){var links=$$('.jump a');if(!links.length||!('IntersectionObserver' in window))return;var map={};links.forEach(function(a){map[a.getAttribute('href').slice(1)]=a});
var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){links.forEach(function(a){a.classList.remove('on')});var a=map[e.target.id];if(a)a.classList.add('on')}})},{rootMargin:'-30% 0px -60% 0px'});
Object.keys(map).forEach(function(id){var el=document.getElementById(id);if(el)io.observe(el)})})();
(function(){var boxes=$$('.sq input');if(!boxes.length)return;var n=$('#sc-n'),t=$('#sc-t'),d=$('#sc-d');
function upd(){var c=boxes.filter(function(b){return b.checked}).length;n.textContent=c;
if(c===0){t.textContent='Tick the statements that apply.';d.textContent='Your result appears here.'}
else if(c<=2){t.textContent='Few indicators so far.';d.textContent='Review the project with a technical lead: the advance sought and the uncertainty may need clearer definition.'}
else if(c<=5){t.textContent='Some indicators of qualifying R&D.';d.textContent='A technical assessment can establish whether the advance and uncertainty tests are met.'}
else{t.textContent='Strong indicators of possible qualifying R&D.';d.textContent='A technical assessment is the next step to confirm eligibility and the qualifying activities.'}}
boxes.forEach(function(b){b.addEventListener('change',upd)});upd()})();
