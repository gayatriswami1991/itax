(function(){
var reduce=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
var fine=window.matchMedia&&window.matchMedia('(pointer:fine)').matches;
var $=function(s,c){return (c||document).querySelector(s)},$$=function(s,c){return Array.prototype.slice.call((c||document).querySelectorAll(s))};
window.$=$;window.$$=$$;
if('IntersectionObserver' in window&&!reduce){
  var vh0=window.innerHeight,items=$$('.rv,.wipe');
  items.forEach(function(el){if(el.getBoundingClientRect().top>vh0*0.95)el.classList.add('pending')});
  document.documentElement.classList.add('anim');
  var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}})},{threshold:0.01,rootMargin:'0px 0px 18% 0px'});
  items.forEach(function(el){if(el.classList.contains('pending'))io.observe(el);else el.classList.add('in')});
  setTimeout(function(){items.forEach(function(el){el.classList.add('in')})},7000);
}
if(!reduce&&fine){
  $$('.mag').forEach(function(b){b.addEventListener('pointermove',function(e){var r=b.getBoundingClientRect();b.style.transform='translate('+((e.clientX-r.left-r.width/2)*.18)+'px,'+((e.clientY-r.top-r.height/2)*.28)+'px)'});b.addEventListener('pointerleave',function(){b.style.transform=''})});
  $$('.tilt').forEach(function(c){c.addEventListener('pointermove',function(e){var r=c.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;c.style.transform='perspective(900px) rotateY('+(x*6)+'deg) rotateX('+(-y*6)+'deg) translateY(-5px)'});c.addEventListener('pointerleave',function(){c.style.transform=''})});
  var hero=$('#hero'),glow=$('#glow');
  if(hero&&glow){hero.addEventListener('pointermove',function(e){var r=hero.getBoundingClientRect();glow.style.opacity=1;glow.style.left=(e.clientX-r.left)+'px';glow.style.top=(e.clientY-r.top)+'px'});hero.addEventListener('pointerleave',function(){glow.style.opacity=0})}
}
window.MAKE_WEBHOOKS={pdf:'https://hook.eu2.make.com/1wn2tf9j4qmrcp4532uak6vpeu4rmgk6',contact:'https://hook.eu2.make.com/1ufcyla1no7bwoprohh6hi4zqame1tg8'};
window.wireForm=function(formId,doneId,errId,fields,type,extraData){
  var f=$('#'+formId),d=$('#'+doneId),err=$('#'+errId);if(!f)return;
  var live=/(^|\.)itaxadvisors\.co\.uk$/.test(location.hostname);
  f.addEventListener('submit',function(e){e.preventDefault();err.textContent='';
    for(var i=0;i<fields.length;i++){var el=$('#'+fields[i]);var bad=el.type==='checkbox'?!el.checked:!el.value.trim();
      if(el.type==='email'&&el.value&&!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(el.value))bad=true;
      if(bad){err.textContent=el.type==='checkbox'?'Please tick the box so we can contact you.':'Please complete: '+(el.labels&&el.labels[0]?el.labels[0].textContent.replace(/\(optional\)/,'').trim():'this field')+'.';el.focus();return}}
    var btn=f.querySelector('button[type="submit"]'),orig=btn.innerHTML;
    function ok(){f.hidden=true;d.classList.add('show')}
    /* Same Make.com webhooks as the live home page. In previews (any other host) no real lead is sent. */
    if(!live){ok();return}
    var data={};new FormData(f).forEach(function(v,k){data[k]=typeof v==='string'?v.trim():v});
    var cb=f.querySelector('input[type="checkbox"]');data.consent=cb&&cb.checked?'yes':'no';
    data.submitted_at=new Date().toISOString();data.page_url=location.href;
    var x=typeof extraData==='function'?extraData():{};Object.keys(x).forEach(function(k){data[k]=x[k]});
    btn.disabled=true;btn.textContent='Sending...';
    fetch(window.MAKE_WEBHOOKS[type||'contact'],{method:'POST',mode:'no-cors',body:new URLSearchParams(data)}).then(ok).catch(function(){err.textContent='We could not send your details. Please try again or contact us by email.';btn.disabled=false;btn.innerHTML=orig});
  });
};
})();

