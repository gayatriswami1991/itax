# iTax Advisors: Developer Guide
**Go-live guide for the redesigned pages.** Everything in this package is body content only: the site header and footer stay as the theme's own.

## 1. What is in the zip

| Folder / file | What it is |
|----------------------------------|------------------------------------------------------------------|
| `DEVELOPER-GUIDE.docx` / `.md` | This guide (same content in both). |
| `developer/<page>/index.html` | The finished page. The `<head>` already has the title, meta description, canonical, Open Graph and schema (JSON-LD). Use the body content for the live page. |
| `developer/assets/css`, `js`, `img` | One CSS file and one JS file per page, plus all images. Keep the folder structure so the relative paths (`../assets/...`) work, or change the paths after uploading. |
| `preview/<page>.html` | Single-file versions with images embedded. Open in a browser to see how the page should look. **Not for the live site.** |
| `preview/_home-page-reference.html` | Reference only. The home page is already live (updated by the client). |
| `lead-magnet-pdfs/` | The three checklist PDFs to upload to the Media Library. |
| `lead-magnet-emails/claim-checklist-emails.md` | Text of the two automatic emails sent when someone downloads a checklist. |


## 2. Page list: current URL and HTML file
All URLs stay the same. Pages marked **NEW** do not exist on the live site yet; create them at the URL shown.

| # | Page | Live URL | HTML file | Action | WordPress type |
|----|----------------------|----------------------------------|----------------------------------|----------------|----------|
| 0 | Home page | `/` | Not in package | Already live (client updated it). No action. | Page |
| 1 | About | `/about-itax-advisors/` | `developer/about-itax-advisors/index.html` | Replace existing page | Page |
| 2 | Senior Management | `/about-itax-advisors/senior-management/` | `developer/senior-management/index.html` | Replace existing page | Page |
| 3 | Contact Us | `/contact-us/` | `developer/contact-us/index.html` | Replace existing page | Page |
| 4 | Services hub | `/itax-advisors-services/` | `developer/rd-tax-services/index.html` | Replace existing page | Page |
| 5 | Service: R&D Claim Preparation | `/r-and-d-tax-claims-preparation/` | `developer/r-and-d-tax-claims-preparation/index.html` | Replace existing page | Page |
| 6 | Service: Claim Review and Risk Assessment | `/itax-advisors-services/claim-review-and-risk-assessment/` | `developer/claim-review-and-risk-assessment/index.html` | Replace existing page | Page |
| 7 | Service: HMRC Enquiry Support | `/itax-advisors-services/hmrc-enquiry-defence-and-support/` | `developer/hmrc-enquiry-defence-and-support/index.html` | Replace existing page | Page |
| 8 | Service: Contemporaneous Reporting | `/itax-advisors-services/contemporaneous-reporting/` | `developer/contemporaneous-reporting/index.html` | Replace existing page | Page |
| 9 | Sector: Life Sciences | `/sectors/life-sciences-rd-tax-relief/` | `developer/life-sciences-rd-tax-relief/index.html` | NEW page | Page |
| 10 | Sector: Software, SaaS and AI | `/sectors/software-saas-ai-rd-tax-relief/` | `developer/software-saas-ai-rd-tax-relief/index.html` | NEW page | Page |
| 11 | Sector: Engineering and Manufacturing | `/sectors/engineering-manufacturing-rd-tax-relief/` | `developer/engineering-manufacturing-rd-tax-relief/index.html` | NEW page | Page |
| 12 | Sector: Construction | `/sectors/construction-architecture-rd-tax-relief/` | `developer/construction-architecture-rd-tax-relief/index.html` | NEW page | Page |
| 13 | Knowledge Hub (main) | `/rd-tax-knowledge-hub-hmrc-guidance-eligibility-documentation/` | `developer/rd-tax-knowledge-hub/index.html` | Replace existing page | Page |
| 14 | Hub: Eligibility | `/rd-tax-knowledge-hub-hmrc-guidance-eligibility-documentation/understanding-rd-eligibility/` | `developer/understanding-rd-eligibility/index.html` | Replace existing page | Page |
| 15 | Hub: R&D Tax Relief Schemes | `/rd-tax-knowledge-hub-hmrc-guidance-eligibility-documentation/rd-tax-reliefs-brief-introduction/` | `developer/rd-tax-reliefs-brief-introduction/index.html` | Replace existing page | Page |
| 16 | Hub: Competent Professional | `/rd-tax-knowledge-hub-hmrc-guidance-eligibility-documentation/the-competent-professional/` | `developer/the-competent-professional/index.html` | Replace existing page | Page |
| 17 | Hub: Qualifying Costs | `/rd-tax-knowledge-hub-hmrc-guidance-eligibility-documentation/rd-qualifying-costs/` | `developer/rd-qualifying-costs/index.html` | Replace existing page | Page |
| 18 | Hub: How to Make a Claim | `/rd-tax-knowledge-hub-hmrc-guidance-eligibility-documentation/how-can-i-make-a-claim/` | `developer/how-can-i-make-a-claim/index.html` | Replace existing page | Page |
| 19 | Hub: FAQs | `/rd-tax-knowledge-hub-hmrc-guidance-eligibility-documentation/faqs/` | `developer/rd-tax-relief-faqs/index.html` | Replace existing page | Page |
| 20 | Insights blog: Contracted-out R&D rules | `/contracted-out-rd-why-it-is-no-longer-as-simple-as-who-did-the-work/` | `developer/contracted-out-rd-rules/index.html` | Replace existing post | Post (Insights) |


### SEO fields to set in Yoast (copy from the table)

| Page | Yoast SEO title | Yoast meta description | H1 (already on the page) | Target keyword |
|----------------|----------------------|----------------------------------|----------------|------------|
| About | About iTax Advisors / UK R&D Tax Specialists | Meet Aarti Varia FCCA and the iTax Advisors team. Discover our specialist experience, compliance-led approach and expertise in UK R&D tax relief. | About iTax Advisors: Senior-Led UK R&D Tax Specialists | iTax Advisors / R&D tax specialist firm UK |
| Senior Management | Aarti Varia FCCA: Founder, R&D Tax Specialist / iTax | Meet Aarti Varia FCCA, founder of iTax Advisors, with over 18 years in R&D tax including 13 years at Deloitte. Specialist, senior-led R&D tax advice. | Aarti Varia FCCA: Founder and R&D Tax Specialist | Aarti Varia FCCA / R&D tax specialist |
| Contact Us | Contact iTax Advisors / UK R&D Tax Specialists | Contact iTax Advisors to discuss your R&D tax claim, independent claim review or HMRC enquiry. Speak to a specialist UK R&D tax adviser. | Contact iTax Advisors: Speak to a Specialist R&D Tax Adviser Today | contact iTax Advisors |
| Services hub | R&D Tax Services UK / Claims, Reviews & HMRC Support | Explore specialist UK R&D tax services, including claim preparation, independent claim reviews, HMRC enquiry support and contemporaneous reporting. | R&D Tax Services UK: Claims, Reviews and HMRC Support | R&D tax services UK |
| Service: R&D Claim Preparation | R&D Tax Claim Preparation UK / iTax Advisors | Prepare a robust UK R&D tax claim with specialist support. We assess project eligibility, qualifying costs, technical narratives and HMRC submission requirements. | R&D Tax Claim Preparation UK: Built to Withstand HMRC Scrutiny | R&D tax claim preparation |
| Service: Claim Review and Risk Assessment | R&D Tax Claim Review & Second Opinion / iTax | Need an independent R&D tax claim review? We assess eligibility, technical narratives, qualifying costs and evidence to identify risks and recommend improvements. | R&D Tax Claim Second Opinion: Independent Review and Risk Assessment | R&D tax claim second opinion |
| Service: HMRC Enquiry Support | HMRC R&D Enquiry Support / Response & Defence – iTax | Received an HMRC R&D enquiry letter? Get specialist support with evidence reviews, technical explanations, cost assessments and structured HMRC responses. | HMRC R&D Enquiry Support: Respond with Confidence | HMRC R&D enquiry support |
| Service: Contemporaneous Reporting | Contemporaneous R&D Reporting UK / iTax Advisors | Strengthen your R&D tax claim evidence throughout the year. iTax Advisors helps businesses document technical activities, uncertainties and qualifying costs. | Contemporaneous R&D Reporting: Build Stronger Claims Year-Round | contemporaneous R&D reporting |
| Sector: Life Sciences | R&D Tax Relief for Life Sciences UK / iTax Advisors | R&D tax relief for life sciences, biotech and MedTech companies: clinical trial costs, CRO contracts, overseas costs and HMRC-ready claims. Speak to a specialist. | R&D Tax Relief for Life Sciences, Biotechnology & MedTech Companies | R&D tax relief life sciences |
| Sector: Software, SaaS and AI | R&D Tax Relief for Software, SaaS & AI / iTax Advisors | R&D tax relief for software, SaaS, AI and fintech companies: what qualifies, developer costs, cloud and contractor spend, and evidence HMRC expects. Speak to a specialist. | R&D Tax Relief for Software Development, SaaS, AI & Fintech Companies | software R&D tax relief / R&D tax relief AI |
| Sector: Engineering and Manufacturing | R&D Tax Relief for Manufacturing & Engineering / iTax Advisors | R&D tax relief for manufacturing and engineering companies: product development, materials, machinery, prototypes and production processes. Speak to a specialist. | R&D Tax Relief for Manufacturing and Engineering Companies | R&D tax relief manufacturing |
| Sector: Construction | R&D Tax Relief for Construction Companies / iTax Advisors | R&D tax relief for construction and the built environment: civil and structural engineering, flood resilience, ground engineering, materials and subcontractor entitlement. | R&D Tax Relief for Construction and the Built Environment | R&D tax relief construction |
| Knowledge Hub (main) | R&D Tax Relief Guide: Eligibility, Costs, Claims / iTax | R&D tax relief guide for UK companies: how the schemes work, eligibility, qualifying costs and how to claim. Practical, HMRC-aware guidance from specialists. | R&D Tax Relief Guide: Eligibility, Costs and How to Claim | R&D tax relief guide |
| Hub: Eligibility | Does Your Project Qualify as R&D? Eligibility Test / iTax | R&D tax relief eligibility explained: the advance and uncertainty tests, what is unlikely to qualify, common misconceptions and sector examples. Try the self-check. | R&D Tax Relief Eligibility: Does Your Project Qualify? | R&D tax relief eligibility |
| Hub: R&D Tax Relief Schemes | R&D Tax Relief Schemes: RDEC & ERIS Explained / iTax | R&D tax relief schemes explained: the merged RDEC scheme and ERIS, rates, R&D intensity, SME definition, who can claim and the payable credit cap. | R&D Tax Relief Schemes: Merged RDEC and ERIS Explained | R&D tax relief schemes UK |
| Hub: Competent Professional | Who Is a Competent Professional for R&D Tax? / iTax | Who is a competent professional in an R&D tax claim? HMRC's description, who can fulfil the role, how expertise is evidenced and how we work with your technical team. | Who Is a Competent Professional in an R&D Tax Claim? | competent professional R&D tax |
| Hub: Qualifying Costs | R&D Qualifying Costs: What Can You Claim? / iTax Advisors | R&D qualifying costs explained: staff, externally provided workers, contracted-out R&D, consumables, software, cloud and data, clinical trial payments and overseas rules. | R&D Qualifying Costs: What You Can Claim (Including Contracted-Out R&D) | R&D tax qualifying costs |
| Hub: How to Make a Claim | How to Claim R&D Tax Relief: Steps, AIF & CT600 / iTax | How to claim R&D tax relief: claim notification, the Additional Information Form, CT600 and the two-year deadline. Step-by-step guidance from specialists. | How to Claim R&D Tax Relief: Notification, AIF and CT600 Steps | how to claim R&D tax relief |
| Hub: FAQs | R&D Tax Relief FAQs: Your Questions Answered / iTax | Answers to common R&D tax relief questions: eligibility, SMEs, R&D intensity, directors' salaries, overseas costs, grants, payable credit caps, claims and HMRC enquiries. | R&D Tax Relief FAQs: Your Questions Answered | R&D tax relief FAQs |
| Insights blog: Contracted-out R&D rules | Contracted Out R&D Rules: Who Can Claim? / iTax Advisors | Contracted out R&D rules from 1 April 2024: who can claim, what 'intended or contemplated' means, the 65% restriction, overseas subcontractors and evidence to keep. | Contracted Out R&D Rules: Why &ldquo;Who Did the Work?&rdquo; Is No Longer the Test | contracted out R&D rules |


## 3. How to put one page live (same steps for every page)

| Step | What to do |
|--------|--------------------------------------------------------------------------------------------|
| 1 | Upload the `developer/assets` folder (css, js, img) to the site, for example to `/wp-content/uploads/itax-pages/assets/`. Keep the sub-folders. |
| 2 | Open the existing page in WordPress (or create the NEW page at the URL in section 2). Keep the slug exactly as listed. |
| 3 | Page settings: full-width content, no sidebar, hide the page title bar and the default title (the H1 is already in the content). Keep the theme header and footer. |
| 4 | Add a Code Block / Custom HTML element and paste everything between `<body>` and `</body>` of `developer/<page>/index.html`. |
| 5 | Load the page CSS and JS: link `assets/css/<page>.css` in the page (or paste the CSS into the page's Custom CSS) and add the `<script src>` line that is at the bottom of the file. Fonts: Raleway (and Inter on the guide pages) from Google Fonts. |
| 6 | Schema: paste the `<script type="application/ld+json">` block from the `<head>` into the page, or into Yoast's schema field. See section 9 for the duplicate-schema rule. |
| 7 | Yoast: set the SEO title and meta description from the table above. Check the canonical equals the live URL. |
| 8 | Check the page on desktop and mobile, and click every link and button. |


## 4. Checklist PDFs and forms: which page needs which PDF
Only **three PDFs** exist. The forms send the lead to Make.com (webhooks are in the page JS) and the automation emails the PDF link. Upload the PDFs to the Media Library first.

| PDF file (in `lead-magnet-pdfs/`) | Where the download form is | Lead source value | Upload and URL |
|----------------------|--------------------------------------|------------------|----------------------|
| `itax-claim-readiness-checklist.pdf` (3 pages) | **Home page** lead-magnet form (client's live page). The pages below only link to it with `/#checklist`: Services hub, R&D Claim Preparation, Claim Review, Contemporaneous Reporting, Knowledge Hub, Eligibility, and the 4 sector pages. | `home-lead-magnet-claim-readiness` | Upload to Media Library. Use this file link in the home form's Make.com scenario. |
| `itax-hmrc-enquiry-response-checklist.pdf` (4 pages) | **Home page** lead-magnet form (HMRC checklist option). The HMRC Enquiry Support page links to it with `/#checklist`. | set in the home page form | Upload to Media Library. The old link (`itax-hmrc-enquiry-checklist.pdf`) returns 404 on the live site: upload with the new file name and update the link in the home form. |
| `itax-clinical-trials-checklist.pdf` (4 pages) | **Life Sciences page** has its own form (section "Clinical Trials & R&D Tax Relief: pre-trial checklist"). It is also a checklist option on the home page. | `life-sciences-page-lead-magnet-clinical-trials` | Upload with this exact file name so the link written in the Life Sciences page JS works: `https://www.itaxadvisors.co.uk/wp-content/uploads/itax-clinical-trials-checklist.pdf`. Otherwise edit `checklist_file` in `assets/js/life-sciences-rd-tax-relief.js`. |


**Forms on the pages in this package**

| Page | Form | Webhook | Notes |
|----------------|----------------------------------|------------|--------------------------------------|
| Contact Us | Enquiry form (name, email, company, type, consent) | `contact` | The only enquiry form. Every other page sends visitors to `/contact-us/`. |
| Life Sciences | Clinical trials checklist form | `pdf` | Sends name, email, company, consent, `checklist_name`, `checklist_file`, `lead_source`. |
| All other pages | None | - | CTA buttons link to `/contact-us/`; checklist links go to `/#checklist` on the home page. |


The forms only post to Make.com when the page is on `itaxadvisors.co.uk`, so previews and staging do not create leads. The call uses `no-cors` mode, so the page cannot read the result. Add spam protection, server-side validation and an error path before launch. The two automatic emails (to the client and to the visitor) are in `lead-magnet-emails/claim-checklist-emails.md`: send the visitor email only when the consent box is ticked.

## 5. Header and footer: what to add where
The pages do **not** contain a header or footer. The live site shows a header menu (About, Services, Sectors, Insights, FAQs, Contact + the "Speak to a specialist" button) and a footer with three link columns (Company, Services, Get in touch). Add the new pages as below.

| Page | Header menu | Footer | Notes |
|--------------------------|--------------------------|----------------------------|--------------------|
| Home | Logo link | - | Already live. |
| About | Keep **About** | Company column: About (already there) | Add a dropdown under About. |
| Senior Management | Dropdown under **About** | Company column: add "Senior management" | Founder profile; linked from About. |
| Services hub | Keep **Services** (top item) | - | Services hub is the parent. |
| 4 service pages (Claim Preparation, Claim Review, HMRC Enquiry Support, Contemporaneous Reporting) | Dropdown under **Services** | Services column (already has all four) | No change to the footer. |
| 4 sector pages (Life Sciences, Software/SaaS/AI, Engineering and Manufacturing, Construction) | Dropdown under **Sectors** (the item currently points to `/#sectors`) | Company column: keep "Sectors" and point it to the first sector page or a short list; or add a fourth link column called Sectors | Publish these pages before adding the menu items. |
| Knowledge Hub (main page) | New item **Knowledge Hub**, placed before Insights | Company column: add "Knowledge Hub" | The WordPress main menu already has "R&D Tax Knowledge Hub"; make sure the new header shows it too. |
| Hub sub-pages: Eligibility, Schemes, Competent Professional, Qualifying Costs, How to Make a Claim, FAQs | Dropdown under **Knowledge Hub** | - | The header "FAQs" item currently goes to `/#faq`. Point it to the new FAQs page or keep both. |
| Contracted-out R&D blog | Not in the menu | - | It is an Insights post: it appears under **Insights** (`/category/rd-tax-guidance/`). |
| Contact Us | Keep **Contact** and the green "Speak to a specialist" button | Get in touch column: Speak to a specialist, LinkedIn, Email | Button and links go to `/contact-us/`. |


**Suggested header menu structure**
```
About
   Senior management
Services
   R&D claim preparation
   Claim review and risk assessment
   HMRC enquiry support
   Contemporaneous reporting
Sectors
   Life sciences
   Software, SaaS and AI
   Engineering and manufacturing
   Construction
Knowledge Hub
   Eligibility
   R&D tax relief schemes
   Competent professional
   Qualifying costs
   How to make a claim
   FAQs
Insights
FAQs (optional if the FAQs page is under Knowledge Hub)
Contact   [Speak to a specialist]
```

## 6. Links to update after the pages are live

| Where | What to change |
|----------------------------------|------------------------------------------------------------------|
| Home page (client's live page): Sectors section tiles | Link the tiles to the four sector pages. There is no page for Utilities. |
| About page and Services hub (in this package) | Sector chips link to `/#sectors` for now. After the sector pages are live, point them to the sector URLs. |
| Hub, Eligibility, Qualifying Costs, Contracted-out blog, Claim pages | They link to the Life Sciences and Software sector pages. Those links return 404 until the sector pages are published, so publish the sector pages first. |
| Breadcrumbs | Each page has a visible breadcrumb. Sector pages use `/#sectors` as the middle crumb; change it if a Sectors index page is created. |
| Old internal links | `/the-competent-professional/` redirects to the hub path. The new pages already link to the hub path (`.../rd-tax-knowledge-hub-hmrc-guidance-eligibility-documentation/the-competent-professional/`). Fix any remaining old links and the stray `__trashed-7` link on the live hub page. |


## 7. Decisions and redirects (not built, needs the client)

| Page / URL | Status | Action |
|--------------------------------------------|----------------|----------------------------------------|
| `/itax-advisors-services/research-and-development-tax-incentives/` (R&D Tax Incentives, long page) | Not rebuilt | Client to decide: merge into the Knowledge Hub and redirect (301), retarget to "R&D tax incentives UK", or leave as is. It overlaps the Knowledge Hub. |
| `.../understanding-rd-eligibility/understanding-rd-eligibility-2/` (examples by sector) | Not rebuilt | Its content is now in the sector tabs on the Eligibility page. Keep the page as is, or redirect it to the Eligibility page (`#sectors`). |
| Pages with no source content | Not built | Startups landing page, Life Sciences location pages (Golden Triangle, Cambridge, Oxford, London), How to choose an R&D adviser, Switch adviser, R&D credit calculator, London adviser page. Content needed from the client first. |


## 8. Suggested go-live order

| Order | Step |
|--------|--------------------------------------------------------------------------------------------|
| 1 | Upload `developer/assets`, and the three PDFs to the Media Library. Set up the Make.com scenarios and emails. |
| 2 | Create and publish the 4 NEW sector pages. |
| 3 | Replace the Knowledge Hub main page and its 6 sub-pages. |
| 4 | Replace the Services hub and the 4 service pages. |
| 5 | Replace About, Senior Management and Contact Us. |
| 6 | Replace the Contracted-out R&D blog post. |
| 7 | Update menus (section 5) and the sector links on the home page (section 6). |
| 8 | Set Yoast titles and descriptions; remove duplicate schema (section 9). |
| 9 | Test both forms and each PDF download link; run a link check. |
| 10 | Submit the updated sitemap in Google Search Console. |


## 9. Technical notes

| Topic | Note |
|------------------------|----------------------------------------------------------------------------|
| Schema (JSON-LD) | Each page has its own schema (Service / AboutPage / ContactPage / CollectionPage / Article / FAQPage / BreadcrumbList). They use the shared business `@id` `https://www.itaxadvisors.co.uk/#organization` (same as Yoast) and a founder `@id` on the Senior Management page. Yoast also prints a WebPage, Organization and BreadcrumbList: keep **one** BreadcrumbList and one Organization, remove the duplicates. |
| Visible breadcrumbs | Each page shows its own breadcrumb. Turn off the theme or Yoast visible breadcrumb on these pages to avoid two. |
| Page content only | No header, footer, cookie banner or chat widget is in the HTML. The fixed header is about 78px high: the pages leave space for it. |
| Fonts | Raleway from Google Fonts (already used on the site). Guide pages also use Inter. |
| Images | All images are in `developer/assets/img` and keep their natural proportions. Do not stretch or crop them. |
| JavaScript | Small vanilla JS per page (tabs, count-up numbers, jump menu, form handling). No libraries. |
| External links not checked | gov.uk links (claim notification form, Additional Information Form) and the LinkedIn link could not be fetched from the build environment: open them once after launch. Every itaxadvisors.co.uk link was checked except the new sector pages, which return 404 until published. |
| Contact details | Address and email are the client's own: iTax Advisors Limited, Devonshire House, 582 Honeypot Lane, HA7 1JS; info@itaxadvisors.co.uk. |


## 10. Items the client should confirm before launch

| Item | Why |
|----------------------------------------------|------------------------------------------------------|
| Testimonials and names (Schneider Electric, Cameron Group, Geolytix) on Senior Management; wording "Big 4" / Deloitte | Taken from the live site. Confirm the client has permission to use them. |
| Compliance chips (PCRT compliant, AML supervised, professional indemnity insured) | Shown on About. Client to confirm they are current. |
| Live FAQs page: R&D intensity "40% from 1 April 2024" | Wrong on the live site. The new pages say 30%, which matches the Schemes page. |
| Live HMRC page and the three checklist PDFs | The old HMRC and clinical PDF links return 404. Upload the new PDFs (section 4). |
| Make.com webhooks and forms | Add spam protection and confirm the webhook scenarios send both emails. |

