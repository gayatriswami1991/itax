# iTax Advisors: final pages (developer package)

Seven pages: About, Contact, Services hub and the four service pages. Header and footer are NOT included; they stay as the site's own shell.

## Folders
- `developer/<page>/index.html`: full page with title, meta description, canonical, Open Graph and schema (JSON-LD) already in the head.
- `developer/assets/img`, `css`, `js`: shared images and one CSS and JS file per page. Paths are relative (`../assets/...`), so upload the `assets` folder and keep the structure, or change the paths to your media library.
- `preview/`: single-file versions with images embedded. Open in any browser to see the finished look. Not for the live site.

## Pages, URLs and SEO
| Page | Live URL (keep the same) | Meta title | Meta description | H1 | Target keyword |
|---|---|---|---|---|---|
| About | https://www.itaxadvisors.co.uk/about-itax-advisors/ | About iTax Advisors | UK R&D Tax Specialists | Meet Aarti Varia FCCA and the iTax Advisors team. Discover our specialist experience, compliance-led approach and expertise in UK R&D tax relief. | About iTax Advisors: Senior-Led UK R&D Tax Specialists | iTax Advisors |
| Contact | https://www.itaxadvisors.co.uk/contact-us/ | Contact iTax Advisors | UK R&D Tax Specialists | Contact iTax Advisors to discuss your R&D tax claim, independent claim review or HMRC enquiry. Speak to a specialist UK R&D tax adviser. | Contact iTax Advisors: Speak to a Specialist R&D Tax Adviser Today | contact iTax Advisors |
| Services hub | https://www.itaxadvisors.co.uk/itax-advisors-services/ | R&D Tax Services UK | Claims, Reviews & HMRC Support | Explore specialist UK R&D tax services, including claim preparation, independent claim reviews, HMRC enquiry support and contemporaneous reporting. | R&D Tax Services UK: Claims, Reviews and HMRC Support | R&D tax services UK |
| Claim Preparation | https://www.itaxadvisors.co.uk/r-and-d-tax-claims-preparation/ | R&D Tax Claim Preparation UK | iTax Advisors | Prepare a robust UK R&D tax claim with specialist support. We assess project eligibility, qualifying costs, technical narratives and HMRC submission requirements. | R&D Tax Claim Preparation UK: Built to Withstand HMRC Scrutiny | R&D tax claim preparation |
| HMRC Enquiry Support | https://www.itaxadvisors.co.uk/itax-advisors-services/hmrc-enquiry-defence-and-support/ | HMRC R&D Enquiry Support | Response & Defence – iTax | Received an HMRC R&D enquiry letter? Get specialist support with evidence reviews, technical explanations, cost assessments and structured HMRC responses. | HMRC R&D Enquiry Support: Respond with Confidence | HMRC R&D enquiry support |
| Claim Review | https://www.itaxadvisors.co.uk/itax-advisors-services/claim-review-and-risk-assessment/ | R&D Tax Claim Review & Second Opinion | iTax | Need an independent R&D tax claim review? We assess eligibility, technical narratives, qualifying costs and evidence to identify risks and recommend improvements. | R&D Tax Claim Second Opinion: Independent Review and Risk Assessment | R&D tax claim second opinion |
| Contemporaneous Reporting | https://www.itaxadvisors.co.uk/itax-advisors-services/contemporaneous-reporting/ | Contemporaneous R&D Reporting UK | iTax Advisors | Strengthen your R&D tax claim evidence throughout the year. iTax Advisors helps businesses document technical activities, uncertainties and qualifying costs. | Contemporaneous R&D Reporting: Build Stronger Claims Year-Round | contemporaneous R&D reporting |

## Notes for the developer
1. **URLs stay the same.** These replace the content of existing live pages. Do not change slugs.
2. **Schema and Yoast.** Each page has its own JSON-LD (Service/AboutPage/ContactPage, FAQPage, BreadcrumbList). Yoast also outputs a WebPage, Organization and BreadcrumbList. Keep only one BreadcrumbList and one Organization/ProfessionalService per page, and keep the FAQPage.
3. **Meta title and description:** set them in Yoast from the table above (they are also in each head).
4. **Page template:** build on a blank page template (as the home page does). The CSS includes base styles (body, headings, buttons) and expects the site's fixed header (78px) above it.
5. **Enquiry form:** only the Contact page has a form. It posts to the same Make.com webhook the home page uses (`contact`), and only on itaxadvisors.co.uk, so previews never send leads. Every other page sends visitors to /contact-us/. Check the Make scenario receives `lead_source = contact-page-form`.
6. **Links:** every itaxadvisors.co.uk link was checked and returns 200. `/#checklist`, `/#sectors`, `/#life-sciences` are anchors on the live home page. Sector tiles on the Services hub and About link to `/#sectors` until sector pages exist. LinkedIn links are copied from the live home page.
7. **Fonts:** Raleway from Google Fonts (already used on the site).
8. **Images:** all images are in the folder and keep their natural proportions (no stretching or cropping).
9. **Not on these pages:** the PDF checklists. The live PDF URLs for the HMRC and clinical trials checklists currently return 404, so check the uploads before relying on the home page lead magnet.


## SEO and accuracy review: what was changed
- Meta titles and descriptions replaced with the reviewed versions (also set as real `<title>` / `<meta name=description>` in each head).
- Schema: one shared `@id` for the business (`https://www.itaxadvisors.co.uk/#organization`, same as Yoast) and for the founder; the Person is linked to the business.
- About: heading changed from the plural 'Ex-Deloitte R&D tax specialists' to 'Founder-led R&D tax expertise'.
- Services hub: 'You receive' line added to each service, the repeated four-step KRID section replaced by a short 'working with your technical and finance teams' section, utilities mentioned alongside the five sectors.
- Claim Preparation: claim notification period now says 'period of account'; dated update that notification is relevant only until 31 March 2027 (source: client checklist, HMRC guidance checked 5 November 2026); AIF same-day sequence added; all 15 readiness checks shown in full; HMRC guidance links added; KRID software wording says experts oversee and the platform does not replace their judgement.
- Claim Review: FAQ reworded ('Who can independently review an existing R&D tax claim?'); upset-my-adviser question replaced by 'What happens if an independent review identifies weaknesses'; timeline clarified.
- HMRC Enquiry Support: prominent deadline warning; time-limit wording qualified (start date depends on company and on whether the return was on time, late or amended); payment hold no longer described as automatically a formal enquiry; new Schedule 36 section; source and review note.
- Contemporaneous Reporting: retrospective comparison reworded to evidence gaps instead of implying extra HMRC scrutiny.
- Contact: 'A few details are enough to get started'; failed-project FAQ reworded so failure alone does not imply eligibility.

## Still needs input from the client (not added, because it is not in the website or documents)
- Case studies and an example claim review report; an illustrative reporting example and downloadable reporting template.
- Expanded founder biography with verifiable credentials links; KRID development story; data protection and validation details for the KRID software; publication and review dates on technical articles.
- A response-time promise for the enquiry confirmation message, and a named UK R&D tax specialist to review the tax wording before launch.
- Form hardening: the Make.com webhook is called in no-cors mode, so the page cannot read the real result. Add server-side validation, spam protection and an error path.
- The home page (client's live page) still says 'Four details are enough to start' and 'Absolutely' in the failed-projects FAQ; update those there too.

Content on every page comes from the live iTax Advisors website (service pages, About, Senior management, KRID page, blog posts) and the documents the client shared (sector documents and the three checklists).