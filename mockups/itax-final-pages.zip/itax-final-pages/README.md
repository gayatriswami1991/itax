# iTax Advisors: final pages (developer package)

Seven pages: About, Contact, Services hub and the four service pages. Header and footer are NOT included; they stay as the site's own shell.

## Folders
- `developer/<page>/index.html`: full page with title, meta description, canonical, Open Graph and schema (JSON-LD) already in the head.
- `developer/assets/img`, `css`, `js`: shared images and one CSS and JS file per page. Paths are relative (`../assets/...`), so upload the `assets` folder and keep the structure, or change the paths to your media library.
- `preview/`: single-file versions with images embedded. Open in any browser to see the finished look. Not for the live site.

## Pages, URLs and SEO
| Page | Live URL (keep the same) | Meta title | Meta description | H1 | Target keyword |
|---|---|---|---|---|---|
| About | https://www.itaxadvisors.co.uk/about-itax-advisors/ | About iTax Advisors | Senior-Led R&D Tax Specialists | Meet iTax Advisors: a senior-led UK R&D tax firm founded by Aarti Varia FCCA, 13 years at Deloitte. See how we build HMRC-ready claims. | About iTax Advisors: Senior-Led UK R&D Tax Specialists | iTax Advisors |
| Contact | https://www.itaxadvisors.co.uk/contact-us/ | Contact iTax Advisors | Speak to an R&D Tax Specialist | Contact iTax Advisors to speak to an R&D tax specialist about your claim or HMRC letter. Send your enquiry and we will arrange a call. | Contact iTax Advisors: Speak to a Specialist R&D Tax Adviser Today | contact iTax Advisors |
| Services hub | https://www.itaxadvisors.co.uk/itax-advisors-services/ | R&D Tax Services UK: Claims, Reviews, Enquiries | iTax | R&D tax claim preparation, second opinions, HMRC enquiry support and contemporaneous reporting from specialist UK advisers. Speak to a specialist. | R&D Tax Services UK: Claims, Reviews and HMRC Support | R&D tax services UK |
| Claim Preparation | https://www.itaxadvisors.co.uk/r-and-d-tax-claims-preparation/ | R&D Tax Claim Preparation UK | HMRC-Ready | iTax | Get an R&D tax claim built to withstand HMRC scrutiny: technical narrative, costs and evidence in one file, led by a senior specialist. Speak to a specialist. | R&D Tax Claim Preparation UK: Built to Withstand HMRC Scrutiny | R&D tax claim preparation |
| HMRC Enquiry Support | https://www.itaxadvisors.co.uk/itax-advisors-services/hmrc-enquiry-defence-and-support/ | HMRC R&D Enquiry Support | Got a Letter? Act Now | Received an HMRC R&D enquiry letter? We handle the written responses and evidence, from the first letter to resolution. Speak to a specialist today. | HMRC R&D Enquiry Support: Respond with Confidence | HMRC R&D enquiry support |
| Claim Review | https://www.itaxadvisors.co.uk/itax-advisors-services/claim-review-and-risk-assessment/ | R&D Tax Claim Second Opinion | Independent Review | Not sure your R&D claim will hold up? Get an independent second opinion on eligibility, costs and evidence, with the risks and fixes in plain English. | R&D Tax Claim Second Opinion: Independent Review and Risk Assessment | R&D tax claim second opinion |
| Contemporaneous Reporting | https://www.itaxadvisors.co.uk/itax-advisors-services/contemporaneous-reporting/ | Contemporaneous R&D Reporting UK | Stronger Claims | Capture R&D activity and costs as projects run, so next year's claim is faster and easier to defend. Set up reporting with senior specialists. | Contemporaneous R&D Reporting: Build Stronger Claims Year-Round | contemporaneous R&D reporting |

## Notes for the developer
1. **URLs stay the same.** These replace the content of existing live pages. Do not change slugs.
2. **Schema and Yoast.** Each page has its own JSON-LD (Service/AboutPage/ContactPage, FAQPage, BreadcrumbList). Yoast also outputs a WebPage, Organization and BreadcrumbList. Keep only one BreadcrumbList and one Organization/ProfessionalService per page, and keep the FAQPage.
3. **Meta title and description:** set them in Yoast from the table above (they are also in each head).
4. **Page template:** build on a blank page template (as the home page does). The CSS includes base styles (body, headings, buttons) and expects the site's fixed header (78px) above it.
5. **Enquiry form:** only the Contact page has a form. It posts to the same Make.com webhook the home page uses (`contact`), and only on itaxadvisors.co.uk, so previews never send leads. Every other page sends visitors to /contact-us/. Check the Make scenario receives `lead_source = contact-page-form`.
6. **Links:** every itaxadvisors.co.uk link was checked and returns 200. `/#checklist`, `/#sectors`, `/#life-sciences` are anchors on the live home page. Sector tiles on the Services hub and About link to `/#sectors` until sector pages exist. LinkedIn links are copied from the live home page.
7. **Fonts:** Raleway from Google Fonts (already used on the site).
8. **Images:** all images are in the folder and keep their natural proportions (no stretching or cropping).
9. **Not on these pages:** the PDF checklists. The live PDF URLs for the HMRC and clinical trials checklists currently return 404, so check the uploads before relying on the home page lead magnet.

Content on every page comes from the live iTax Advisors website (service pages, About, Senior management, KRID page, blog posts) and the documents the client shared (sector documents and the three checklists).